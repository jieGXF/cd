import copy
import json
import os
import pandas as pd
from glob import glob
import numpy as np
from sklearn.preprocessing import StandardScaler
from feature_reduction.reliability_analysis import filter_features_ICC
from feature_extraction.feature_extractor import FeatureExtractor
from feature_reduction.feature_selector import FeatureSelector
from sklearn.model_selection import train_test_split
from batchgenerators.utilities.file_and_folder_operations import *
from batchgenerators.utilities.file_and_folder_operations import save_json, subfiles, join
from sklearn.preprocessing import StandardScaler, OneHotEncoder, MinMaxScaler
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
# from sklearn_features.transformers import DataFrameSelector
from sklearn.feature_selection import SelectKBest, RFE, SelectFromModel, f_regression, f_classif, RFECV, mutual_info_classif
from sklearn.linear_model import LogisticRegression, Lasso, LassoCV
from sklearn.ensemble import RandomForestRegressor, AdaBoostRegressor, GradientBoostingClassifier, AdaBoostClassifier, RandomForestClassifier
from sklearn.pipeline import FeatureUnion
from sklearn.model_selection import GridSearchCV, KFold, cross_val_score, StratifiedKFold, LeaveOneOut
from sklearn.metrics import RocCurveDisplay, roc_auc_score, confusion_matrix, ConfusionMatrixDisplay, auc
from sklearn import metrics
from sklearn.svm import LinearSVC, SVC, SVR
from preprocessing.util import DataFrameMerge
from collections import OrderedDict
# from plotting.plot_ROC import plot_single_ROC
from sklearn.metrics import classification_report, ConfusionMatrixDisplay
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import GaussianNB
from feature_reduction.selector_2nd import best_feature_selection
from preprocessing.feat_encoder import onehot_encoder
from feature_reduction.feat_transformer import feat_transformer
from imblearn.over_sampling import SMOTE
from preprocessing.util import distinguish_Char_Num
# from sklearn.calibration import calibration_curve, CalibrationDisplay
import matplotlib
import matplotlib.pyplot as plt
from plotting.plot_ROC import plot_cv_roc
from plotting.plot_calibration_curves import plot_calibration_curves
from plotting.plot_DCA import plot_DCAs
import seaborn as sns
from evaluation.rocs_comparison import DeLong_test
matplotlib.use('Agg')
from plotting.plot_confusion_matrix import plot_cm
# matplotlib.use('TkAgg')
from pickle import dump
import simpleNomo
def fex_cv(data):
    quality_ls = list(set(data['ID']))
    cols = list(data.iloc[:, 2:])
    mean_ls = []
    std_ls = []
    nums = 2
    for i in cols:
        col_data = data[i]
        col_data = col_data.sort_values()
        col_data = col_data[nums:-nums]
        m_ls = np.mean(col_data)
        s_ls = np.std(col_data)
        mean_ls.append(m_ls)
        std_ls.append(s_ls)
    mean_df = pd.DataFrame(mean_ls, index=cols, columns=["coef"]).T
    std_df = pd.DataFrame(std_ls, index=cols, columns=["coef"]).T
    CV_df = std_df / mean_df
    # print(CV_df)
    # CV_df_mean = CV_df.mean()
    # CV_fin = np.array(list(CV_df_mean))
    # res1 = makefigure(CV_df_mean, CV_fin, 'r')
    return CV_df

def train_binary_classification(input_path, output_path, pora_config):
    subject_name = pora_config["subject_name"]
    label_name = list(pora_config["label_name"].keys())
    maybe_mkdir_p(output_path)
    # internal_path = os.path.join(input_path, 'internal')
    internal_image_path = os.path.join(input_path, 'radiology')
    internal_omics_path = os.path.join(input_path, 'multiomics')
    cv_method = pora_config["cv_method"]
    feat_transformation = pora_config["feat_transformation"]
    models = pora_config["models"]
    num_trials = pora_config["num_trials"]
    ICC_internal_path = os.path.join(output_path, 'ICC', 'internal')

    selectors = {
        'LASSO': {"selector": SelectFromModel(LassoCV(max_iter=100000)),
                  "selector__max_features": np.arange(1, 20)
                  },

        'UFS': {"selector": SelectKBest(f_classif),
                "selector__k": np.arange(1, 20)
                },

        'MI': {"selector": SelectKBest(mutual_info_classif),
                "selector__k": np.arange(1, 20)
                },

        'RFE': {
                "selector": RFE(SVC(kernel="linear")),
                # "selector": RFE(LinearSVC()),
                "selector__n_features_to_select": np.arange(1, 10, 2),
                },

        "AB": {"selector": SelectFromModel(AdaBoostRegressor(random_state=0, n_estimators=50)),
               "selector__alphas": np.linspace(0, 0.2, 21).tolist(),
               "selector__max_features": np.arange(1, 20)
               },
    }

    classifiers = {
        'LR': {'classifier': LogisticRegression(solver='lbfgs'),
               'classifier__C': [0.01, 0.1, 1.0, 10, 100]
               },

        'SVM': {'classifier': SVC(probability=True),
                # 'classifier__kernel': ['linear', 'poly', 'rbf'],
                'classifier__C': np.logspace(-1, 1, 5),
                'classifier__gamma': np.logspace(-9, 3, 13)
                },

        'NB': {'classifier': GaussianNB()},

        "DT": {"classifier": DecisionTreeClassifier(),
               "classifier__criterion": ['entropy', 'gini'],
               "classifier__max_depth": np.arange(5, 30)},

        "RF": {"classifier": RandomForestClassifier(random_state=14),
                         "classifier__n_estimators": [5, 10, 20],
                         "classifier__criterion": ["gini", "entropy"],
                         "classifier__min_samples_leaf": [1, 3, 5]},

        'AB': {"classifier": AdaBoostClassifier(base_estimator=DecisionTreeClassifier()),
               # "classifier__base_estimator__criterion": ["gini", "entropy"],
               # "classifier__base_estimator__splitter": ["best", "random"],
               "classifier__n_estimators": [1, 3, 5],
               },

        "GradientBoosting": {'classifier': GradientBoostingClassifier(learning_rate=0.1, n_estimators=60,
                                                                      min_samples_leaf=20,
                                                                      max_features='sqrt',
                                                                      subsample=0.8, random_state=10),
                             # 'classifier__max_depth': range(3, 14, 2),
                             # 'classifier__min_samples_split': range(100, 801, 200)
                             },
    }

    if cv_method == "Simple":
        results_summ = pd.DataFrame(columns=['seed', 'model', 'selector', 'classifier', 'train_auc', 'test_auc'])
        seed = 27
        print("random seed = " + str(seed))
        print(" "*4 + "data splitting ..., ", end="")
        # df = pd.read_csv(os.path.join(internal_omics_path, pora_config["label_file"]))
        # df = pd.read_csv(os.path.join(ICC_internal_path, pora_config["label_file"]))
        df = pd.read_csv(os.path.join(ICC_internal_path, "Tumor_cls.csv"))
        train, test = train_test_split(df, test_size=0.3, random_state=seed, stratify=df[["tumor_cls"]])
        median_value = np.median(train["dose"])
        print(median_value)
        f = lambda s: 1 if s["dose"] >= median_value else 0
        train["dose"] = train.apply(f, axis=1)
        test["dose"] = test.apply(f, axis=1)
        # train, test = train_test_split(df, test_size=0.3, random_state=seed, stratify=df["dose_3"])
        # train = train.drop(["dose_3"], axis=1)
        # test = test.drop(["dose_3"], axis=1)
        # df_temp = df.drop(["dose_3"], axis=1)
        # df_temp.to_csv(os.path.join(ICC_internal_path, pora_config["label_file"]), index=False)

        train = train.sort_index(axis=0)
        train_y = train[label_name]
        train_y_counts = train_y[label_name].value_counts()
        # y_train_counts = y_train_counts.to_dict()
        test = test.sort_index(axis=0)
        test_y = test[label_name]
        test_y_counts = test_y[label_name].value_counts()
        # y_test_counts = y_test_counts.to_dict()
        train_y_num = train_y_counts[0] + train_y_counts[1]
        if 0.4 < train_y_counts[0]/train_y_num < 0.6:
            is_bal = True
        else:
            is_bal = False
        # save label counts
        summary_each_seed = OrderedDict()
        summary_each_seed["train label counts"] = []
        summary_each_seed["test label counts"] = []
        train_label_count = dict()
        test_label_count = dict()
        for i in range(len(train_y_counts.index)):
            train_label_count[str(train_y_counts.index[i][0])] = int(train_y_counts[i])
            test_label_count[str(test_y_counts.index[i][0])] = int(test_y_counts[i])
        summary_each_seed["train label counts"].append(train_label_count)
        summary_each_seed["test label counts"].append(test_label_count)
        save_dir = os.path.join(output_path, cv_method, str(seed))
        maybe_mkdir_p(str(save_dir))
        json_each_seed = os.path.join(output_path, cv_method, str(seed), "dataset_split.json")
        save_json(summary_each_seed, str(json_each_seed))
        print("done.")

        # TODO: onehotEncoder and feature standardization
        print(" "*4 + "data preprocessing ..., ", end="")
        moda_list = os.listdir(ICC_internal_path)
        non_rad_list = os.listdir(internal_omics_path)
        non_rad_list.remove("radiomics")
        save_dir = os.path.join(output_path, cv_method, str(seed), "feat_scaler")
        maybe_mkdir_p(str(save_dir))
        for moda in moda_list:
            df = pd.read_csv(os.path.join(ICC_internal_path, moda))
            if non_rad_list and moda in non_rad_list:
                # df = onehot_encoder(df, subject_name, label_name)
                # df2 = copy.deepcopy(df)
                # O_index, C_index = distinguish_Char_Num(df2) # distinguish cat variables by character or numerical
                ## 离散变量标签化 onhot_encoder
                # for i in range(len(C_index)):
                #     df[C_index[i]] = LabelEncoder().fit_transform(df[C_index[i]])
                cat_index = pora_config["cat_variable"]
                cats = list(set(cat_index) & set(df.columns.to_list()))
                if cats:
                    num_index = df.columns.drop(subject_name + label_name + cats).to_list()
                    df = onehot_encoder(df, subject_name, label_name, cats)
                    cats_encoder = df.columns.drop(subject_name + label_name + num_index).to_list()
                else:
                    num_index = df.columns.drop(subject_name + label_name).to_list()
                # num_index = df.columns.drop(subject_name + label_name + cat_index).to_list()
                # df = onehot_encoder(df, subject_name, label_name, cat_index)
                # non_num_index = df.columns.drop(num_index).to_list()
                train_X = df.iloc[train.index]
                test_X = df.iloc[test.index]
                if num_index:
                    # scaler = StandardScaler()
                    scaler = MinMaxScaler()
                    train_X_tmp = scaler.fit_transform(train_X[num_index])
                    test_X_tmp = scaler.transform(test_X[num_index])
                    train_X_tmp = pd.DataFrame(train_X_tmp, columns=num_index)
                    train_X_tmp.index = train.index
                    test_X_tmp = pd.DataFrame(test_X_tmp, columns=num_index)
                    test_X_tmp.index = test.index
                    # train_X = pd.concat([train_X[non_num_index], train_X_tmp], axis=1)
                    # test_X = pd.concat([test_X[non_num_index], test_X_tmp], axis=1)
                    if cats:
                        train_X = pd.concat([train_X[subject_name + label_name + cats_encoder], train_X_tmp], axis=1)
                        test_X = pd.concat([test_X[subject_name + label_name + cats_encoder], test_X_tmp], axis=1)
                    else:
                        train_X = pd.concat([train_X[subject_name + label_name], train_X_tmp], axis=1)
                        test_X = pd.concat([test_X[subject_name + label_name], test_X_tmp], axis=1)
                    dump(scaler, open(os.path.join(str(save_dir), moda[:-4] + '_scaler.pkl'), 'wb'))
            else:

                # df_tmp = df.drop(subject_name + label_name, axis=1)
                # df_tmp = df_tmp.rename(columns=lambda x: moda[:-4] + "_" + x)
                # df = pd.concat([df[subject_name + label_name], df_tmp], axis=1)
                # not add the prefix in variable name after pyradiomics 3.1
                train_X = df.iloc[train.index]
                train_X_tmp = train_X.drop(subject_name + label_name, axis=1)

                cv_coef = fex_cv(train_X)
                cv_coef.to_csv(os.path.join(save_dir, moda[:-4] + '_cv.csv'), sep=",", mode="w")
                to_drop_cv = [column for column in cv_coef.columns if any(cv_coef[column] < 0.5)]
                train_X_tmp = train_X_tmp.drop(to_drop_cv, axis=1)

                train_X_tmp.to_csv(os.path.join(save_dir, moda[:-4] + '_cv_filter.csv'), index=False)

                scaler = StandardScaler()
                # scaler = MinMaxScaler()
                train_X_tmp2 = scaler.fit_transform(train_X_tmp)
                train_X_tmp2 = pd.DataFrame(train_X_tmp2, columns=train_X_tmp.columns)
                # pearson correlation coefficient
                corr_matrix = train_X_tmp2.corr().abs()
                upper = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(np.bool_))
                to_drop = [column for column in upper.columns if any(upper[column] > 0.95)]
                train_X_tmp2 = train_X_tmp2.drop(to_drop, axis=1)
                train_X_tmp2.index = train.index
                train_X = pd.concat([train_X[subject_name + label_name], train_X_tmp2], axis=1)
                train_X.to_csv(os.path.join(save_dir, moda[:-4] + '_pcc.csv'), index=False)
                test_X = df.iloc[test.index]
                test_X_tmp = test_X.drop(subject_name + label_name, axis=1)
                test_X_tmp = test_X_tmp.drop(to_drop_cv, axis=1)
                test_X_tmp2 = scaler.transform(test_X_tmp)
                test_X_tmp2 = pd.DataFrame(test_X_tmp2, columns=test_X_tmp.columns)
                test_X_tmp2 = test_X_tmp2.drop(to_drop, axis=1)
                test_X_tmp2.index = test.index
                test_X = pd.concat([test_X[subject_name + label_name], test_X_tmp2], axis=1)
                dump(scaler, open(os.path.join(str(save_dir), moda[:-4] + '_scaler.pkl'), 'wb'))
            locals()[moda[:-4] + "_train"] = train_X
            locals()[moda[:-4] + "_test"] = test_X
        print("done.")

        if pora_config["is_feat_transformation"]:
            print(" "*4 + "features are being transformed ..., ", end="")
            for reduced_moda in feat_transformation.keys():
                from preprocessing.util import DataFrameMerge
                dfm = DataFrameMerge(label_name)
                combo_list = list(feat_transformation[reduced_moda].keys())[0].split('+')
                combo_train = dict()
                combo_test = dict()
                for moda in combo_list:
                    combo_train[moda] = locals()[moda + "_train"]
                    combo_test[moda] = locals()[moda + "_test"]
                # X_train, X_test = dfm.merge(combo_list, combo_train, combo_test)
                # X_train = X_train.drop(subject_name + label_name, axis=1)
                # X_test = X_test.drop(subject_name + label_name, axis=1)
                train_X = dfm.merge(combo_list, combo_train)
                test_X = dfm.merge(combo_list, combo_test)
                # train_X = train_X.drop(subject_name + label_name, axis=1)
                # test_X = test_X.drop(subject_name + label_name, axis=1)

                save_dir = os.path.join(output_path, cv_method, str(seed), "feat_transformation")
                maybe_mkdir_p(str(save_dir))
                feat_tf = feat_transformer(train_X, train_y, test_X , subject_name, label_name, reduced_moda)
                # df_train, df_test = feat_tf.run_transformer(
                #     list(feat_transformation[reduced_moda].values())[0])
                df_train, df_test,  ft_log = feat_tf.run_transformer(list(feat_transformation[reduced_moda].values())[0])
                ft_log.to_csv(os.path.join(save_dir, reduced_moda+'_log.csv'), sep=",", mode="w")

                locals()[reduced_moda + "_train"] = df_train.set_index(train.index)
                locals()[reduced_moda + "_test"] = df_test.set_index(test.index)
                locals()[reduced_moda + "_train"].to_csv(os.path.join(str(save_dir), reduced_moda + "_train.csv"), mode='w')
                locals()[reduced_moda + "_test"].to_csv(os.path.join(str(save_dir), reduced_moda + "_test.csv"), mode='w')
            print("done.")

        # model construction pipeline
        selectors = {key: value for key, value in selectors.items()
                     if key in pora_config["selectors"]}
        classifiers = {key: value for key, value in classifiers.items()
                       if key in pora_config["algorithms"]}
        all_train_fpr = dict()
        all_train_tpr = dict()
        all_train_auc = dict()
        all_test_fpr = dict()
        all_test_tpr = dict()
        all_test_auc = dict()
        preds_train = OrderedDict()
        preds_test = OrderedDict()
        for md_name in models.keys():
            print(" "*4 + md_name + " model constructing :")
            combo_list = models[md_name]
            combo_train = dict()
            combo_test = dict()
            for feat in combo_list:
                combo_train[feat] = locals()[feat + "_train"]
                combo_test[feat] = locals()[feat + "_test"]
            from preprocessing.util import DataFrameMerge
            dfm = DataFrameMerge(label_name)
            train_X = dfm.merge(combo_list, combo_train)
            test_X = dfm.merge(combo_list, combo_test)
            train_X = train_X.drop(subject_name + label_name, axis=1)
            test_X = test_X.drop(subject_name + label_name, axis=1)

            # imbalance data processing
            if not is_bal:
                smote = SMOTE(random_state=0)
                train_bal_X, train_bal_y = smote.fit_resample(train_X, train_y)
            else:
                train_bal_X = copy.deepcopy(train_X)
                train_bal_y = copy.deepcopy(train_y)

            aucs_heatmap_test = pd.DataFrame(columns=list(classifiers.keys()), index=list(selectors.keys()))
            aucs_heatmap_train = pd.DataFrame(columns=list(classifiers.keys()), index=list(selectors.keys()))
            best_clf_list = list()
            pred_train = OrderedDict()
            pred_test = OrderedDict()
            for j, clf in enumerate(classifiers):
                best_sel_list = list()
                sel_pred_train = OrderedDict()
                sel_pred_test = OrderedDict()
                for i, sel in enumerate(selectors):
                    save_dir = os.path.join(output_path, cv_method, str(seed), "models", md_name, sel, clf)
                    maybe_mkdir_p(str(save_dir))
                    print(" " * 8 + sel + " + " + clf + " grid search ..., ", end="")
                    pp = Pipeline(steps=[('selector', list(selectors[sel].values())[0]),
                                         ('classifier', list(classifiers[clf].values())[0])])
                    # pp = Pipeline(steps=[
                    #                      ('classifier', list(classifiers[clf].values())[0])])
                    search_space = dict()
                    search_space.update(selectors[sel])
                    search_space.update(classifiers[clf])
                    del search_space["selector"]
                    del search_space["classifier"]
                    grid_search = GridSearchCV(pp, search_space, cv=5, refit=True,
                                               scoring='roc_auc')
                    grid_search.fit(train_bal_X, train_bal_y.values.ravel())
                    display_labels = grid_search.classes_
                    best_sel_list.append(tuple([grid_search.best_estimator_, sel]))
                    train_y_pred = grid_search.predict(train_X)
                    test_y_pred = grid_search.predict(test_X)
                    train_y_prob = grid_search.predict_proba(train_X)
                    test_y_prob = grid_search.predict_proba(test_X)
                    train_y_prob_pd = pd.DataFrame(train_y_prob, columns=["predict_0", "predict_1"])
                    train_y_prob_pd.index = train.index
                    train_output = pd.concat([train, train_y_prob_pd], axis=1, sort=False)
                    train_output.to_csv(os.path.join(str(save_dir), 'train_prob.csv'))
                    test_y_prob_pd = pd.DataFrame(test_y_prob, columns=["predict_0", "predict_1"])
                    test_y_prob_pd.index = test.index
                    test_output = pd.concat([test, test_y_prob_pd], axis=1, sort=False)
                    test_output.to_csv(os.path.join(str(save_dir), 'test_prob.csv'))
                    sel_pred_train[sel] = {
                        'labels': train_y,
                        'pred_labels': train_y_pred,
                        'pred_scores': train_y_prob
                    }
                    sel_pred_test[sel] = {
                     'labels': test_y,
                     'pred_labels': test_y_pred,
                     'pred_scores': test_y_prob
                    }

                    # TODO optimal feature selection process
                    save_dir = os.path.join(output_path, cv_method, str(seed), "models", md_name, sel, clf)
                    maybe_mkdir_p(str(save_dir))
                    dump(grid_search, open(os.path.join(str(save_dir), 'model.pkl'), 'wb'))
                    plot_cm(tag='train', y_true=train_y, y_pred=train_y_pred,
                            display_labels=display_labels, save_dir=save_dir)
                    plot_cm(tag='test', y_true=test_y, y_pred=test_y_pred,
                            display_labels=display_labels, save_dir=save_dir)

                    summary_each_pp = OrderedDict()
                    selected_features = best_feature_selection(train_X, sel, grid_search, save_dir)
                    # selector = grid_search.best_estimator_.named_steps.selector.estimator_
                    # selector_idx = grid_search.best_estimator_.named_steps.selector.get_support()
                    # feature_name = train_X.columns.values[selector_idx]
                    # feature_name = pd.DataFrame(feature_name.transpose())
                    # feature_name.to_csv(os.path.join(save_dir, 'feature_name.csv'))
                    # json_output = os.path.join(save_dir, "summary.json")
                    # summary_each_pp["best_params"] = grid_search.best_params_
                    # calculate and plot metrics
                    # train/test ROCs comparison (cutoff value)
                    train_fpr, train_tpr, thresholds = metrics.roc_curve(train_y, train_y_prob[:, 1],
                                                                         pos_label=1)
                    train_auc = metrics.roc_auc_score(train_y, train_y_prob[:, 1])
                    optimal_idx = np.argmax(train_tpr - train_fpr)
                    optimal_threshold = thresholds[optimal_idx]
                    all_train_fpr[md_name] = train_fpr
                    all_train_tpr[md_name] = train_tpr
                    all_train_auc[md_name] = train_auc
                    youden = train_tpr - train_fpr
                    cutoff = thresholds[np.argmax(youden)]

                    if clf == "LR":
                        nomogram = pd.DataFrame(columns=['feature', 'coef', 'min', 'max', 'type', 'position'])
                        nomogram["feature"] = ["intercept", "threshold"] + selected_features["name"].tolist()
                        nomogram["coef"] = np.append(np.array([grid_search.best_estimator_.named_steps.classifier.intercept_[0],
                                            cutoff]), grid_search.best_estimator_.named_steps.classifier.coef_)
                        for n in selected_features["name"].tolist():
                            index = nomogram[nomogram["feature"] == n].index.tolist()[0]

                            if cat_index[0] in n:
                                nomogram.loc[index, "type"] = "nominal"
                                nomogram.loc[index, "min"] = int(train_X[n].min())
                                nomogram.loc[index, "max"] = int(train_X[n].max())
                            else:
                                nomogram.loc[index, "type"] = "continuous"
                                nomogram.loc[index, "min"] = train_X[n].min()
                                nomogram.loc[index, "max"] = train_X[n].max()

                    nomogram.to_excel(os.path.join(str(save_dir), 'nomogram.xlsx'))
                    # cmv_nomo = simpleNomo.nomogram(os.path.join(str(save_dir), 'nomogram.xlsx'))
                    test_fpr, test_tpr, _ = metrics.roc_curve(test_y, test_y_prob[:, 1], pos_label=1)
                    test_auc = metrics.roc_auc_score(test_y, test_y_prob[:, 1])
                    all_test_fpr[md_name] = test_fpr
                    all_test_tpr[md_name] = test_tpr
                    all_test_auc[md_name] = test_auc

                    results_summ = pd.concat([results_summ, pd.DataFrame(
                        {'seed': [seed], 'model': [md_name], 'selector': [sel], 'classifier': [clf],
                         'train_auc': [train_auc], 'test_auc': [test_auc]})], ignore_index=True)

                    # ROCs for each combination of feature selector and classifier
                    fig, ax = plt.subplots(figsize=(7.5, 7.5))
                    plt.plot(train_fpr, train_tpr, label='train (AUC = %0.2f)' % train_auc)
                    plt.plot(test_fpr, test_tpr, label='test (AUC = %0.2f)' % test_auc)
                    plt.plot([0, 1], [0, 1], linestyle='--', color='red', label='chance level')
                    plt.xlim([-0.05, 1.05])
                    plt.ylim([-0.05, 1.05])
                    plt.xlabel('False positive rate')
                    plt.ylabel('True positive rate')
                    plt.legend(loc="lower right")
                    plt.savefig(os.path.join(str(save_dir), 'ROCs.png'))
                    plt.close()
                    # confusion matrix
                    train_report = classification_report(train_y, grid_search.predict(train_X),
                                                         output_dict=True)
                    summary_each_pp["train_report"] = train_report
                    # train_report = pd.DataFrame(train_report).transpose()
                    # train_report.to_csv(os.path.join(save_dir, 'train_report.csv'))
                    test_report = classification_report(test_y, grid_search.predict(test_X), output_dict=True)
                    # test_report = pd.DataFrame(test_report).transpose()
                    # test_report.to_csv(os.path.join(save_dir, 'test_report.csv'))
                    summary_each_pp["test_report"] = test_report
                    # with open(json_output, "w") as f:
                    #     json.dump(summary_each_pp, f, sort_keys=True, indent=4, separators=(',', ':'),
                    #               cls=NpEncoder)
                    train_cm = confusion_matrix(y_true=train_y, y_pred=grid_search.predict(train_X))
                    vis = ConfusionMatrixDisplay(confusion_matrix=train_cm)
                    vis.plot()
                    plt.savefig(os.path.join(str(save_dir), 'train_confusion_matrix.png'))
                    test_cm = confusion_matrix(y_true=test_y, y_pred=grid_search.predict(test_X))
                    vis = ConfusionMatrixDisplay(confusion_matrix=test_cm)
                    vis.plot()
                    plt.savefig(os.path.join(str(save_dir), 'test_confusion_matrix.png'))
                    # train and test metrics for different combination of feature selector and classifier
                    aucs_heatmap_train[clf][sel] = train_auc
                    aucs_heatmap_test[clf][sel] = test_auc

                    # TODO: find the best selector under the same classifier
                    # list(selectors.keys())[aucs_heatmap_test[clf].astype("float64").argmax()]
                    best_sel_idx = aucs_heatmap_test[clf].astype("float64").argmax()
                    best_clf_list.append([best_sel_list[aucs_heatmap_test[clf].astype("float64").argmax()][0], clf])
                    pred_train[clf] = sel_pred_train[list(selectors.keys())[0]]
                    pred_test[clf] = sel_pred_test[list(selectors.keys())[0]]
                    print("done.")

            preds_train[md_name] = pred_train
            preds_test[md_name] = pred_test
            aucs_heatmap_train[list(aucs_heatmap_train.columns)] = aucs_heatmap_train[
                list(aucs_heatmap_train.columns)].astype(float)
            plt.figure(dpi=120)
            sns.heatmap(data=aucs_heatmap_train,
                        cmap=plt.get_cmap('Set3'),
                        annot=True,
                        )
            plt.title(md_name)
            plt.savefig(os.path.join(output_path, cv_method, str(seed), "models", md_name,
                                     'train_aucs_heatmap.png'))
            aucs_heatmap_test[list(aucs_heatmap_test.columns)] = aucs_heatmap_test[
                list(aucs_heatmap_test.columns)].astype(float)
            plt.figure(dpi=120)
            sns.heatmap(data=aucs_heatmap_test,
                        cmap=plt.get_cmap('Set3'),
                        annot=True,
                        )
            plt.title(md_name)
            plt.savefig(os.path.join(output_path, cv_method, str(seed), "models", md_name,
                                     'test_aucs_heatmap.png'))

            # plotting calibration curves
            save_dir = os.path.join(output_path, cv_method, str(seed), "models", md_name)
            plot_calibration_curves("train", best_clf_list, train_X, train_y, save_dir)
            plot_calibration_curves("test", best_clf_list, test_X, test_y, save_dir)
        save_dir = os.path.join(output_path, cv_method, str(seed), "models")
        # compare two rocs with DeLong test
        DeLong_test("train", preds_train, save_dir)
        DeLong_test("test", preds_test, save_dir)
        # plot decision curve analysis
        plot_DCAs("train", preds_train, save_dir)
        plot_DCAs("test", preds_test, save_dir)

        # TODO record information
        results_summ.to_csv(os.path.join(str(output_path), cv_method, 'results_summ.csv'),
                            sep=",", index=False, mode="w")
        print("all trails are conducted successfully!")
        # series = pd.DataFrame.from_dict(all_seeds_train_auc, orient='index')
        # series.to_csv(os.path.join(results_dir, cv_method, 'all_seeds_train_auc.csv'), index=False)
        # series = pd.DataFrame.from_dict(all_seeds_test_auc, orient='index')
        # series.to_csv(os.path.join(results_dir, cv_method, 'all_seeds_test_auc.csv'), index=False)
        # step 9: summarize the AUCs of target models with different seed and their DeLong tests
        # best selector


    elif cv_method == "K-Fold":
        pass